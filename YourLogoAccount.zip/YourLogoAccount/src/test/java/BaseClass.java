import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeSuite;

import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;

public class BaseClass {

    public WebDriver webDriver;

    @BeforeSuite
    public void setTestSuite() throws MalformedURLException {
        {
            System.setProperty("webdriver.chrome.driver", "D:\\ITEA\\ChromeDriver\\chromedriver.exe");
            WebDriver webDriver= new ChromeDriver();
            webDriver.get("http://automationpractice.com/index.php?controller=authentication&back=my-account");
            webDriver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

            LoginPage loginPage = new LoginPage(webDriver);

            loginPage.inputUsername("vvyastrubchak@gmail.com");
            loginPage.inputPassword("Pass_123");
            loginPage.enterButtonSignIn();
        }
    }


}

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class ChangePasswordTest extends BaseClass {


        @Test
        public void testPasswordChanged() {
            AccountPage accountPage = new AccountPage(webDriver);
            accountPage.tapButtonBackToYourAccount();
            accountPage.enterCurrentPassword("Pass_123");
            accountPage.enterNewPassword("pass_123");
            accountPage.enterConfirmNewPassword("pass_123");
            accountPage.tapButtonSave();
            accountPage.tapButtonSignOut();


        }
    }

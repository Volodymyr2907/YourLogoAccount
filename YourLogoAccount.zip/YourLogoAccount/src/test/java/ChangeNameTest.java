import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import java.util.concurrent.TimeUnit;

public class ChangeNameTest extends BaseClass  {


    @Test
    public void testChangeName() {
        AccountPage accountPage = new AccountPage(webDriver);
        accountPage.openPesrInfo();
        accountPage.enterNewFirstName("Vlad");
        accountPage.enterCurrentPassword("Pass_123");
        accountPage.tapButtonSave();

        String actualUserAccountName = accountPage.getUserAccountName();
        String expectedUserAccountName = "Vlad Yastrubchak";
        Assert.assertEquals(actualUserAccountName,expectedUserAccountName);
    }
}
